#include "DwalWithJsonString.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
	string strSourceFileName = "MyJsonSource.txt";
	cout << "����ִ�г����Ŀ¼�½�һ��  " << strSourceFileName << endl;
	ReadSourceJsonString()

	return 0;
}